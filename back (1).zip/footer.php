<div class="footer">Copyrights@OrderPizza.com(A Level Proj)</div>
<div class="border" align="center">