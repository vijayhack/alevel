<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>A Level</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="main" >
<?php include('header.php');
?>
<div class="body">

<div class="adminleft">
<?php include('left.php'); ?>
</div>


<div class="adminright">
<br />
<h1 style=" margin-left:0px; margin-right:10px;color:#942423">About Us</h1>


<p style="text-align: justify; margin-left:0px; margin-right:70px">OrderPizza constantly strives to develop products that suit the tastes of our consumers and hence delighting them. We believes strongly in the strategy of "Think global and act local". Thus, time and again we have been innovating with delicious new products such as crusts, toppings and flavours suitable to the taste buds of Indian Consumers. Further providing value for money and affordable products to our consumers has been an important part of our efforts. Our initiatives such as Fun Meal and Pizza Mania have been extremely popular with consumers looking for an affordable and value for money meal option.

We believe that when a box of pizza is opened, family and friends come together to share the pizza. Hence, our brand positioning: "Yeh Hai Rishton Ka Time"

That's why, all our efforts, whether it is a new innovative and delicious product, offering consumers value for money deals, great service, countrywide presence or the promise to deliver in 30 minutes or free are all directed towards making relationships stronger, warmer and more fun by giving consumers an opportunity to get together, catch up, reunite and spend more time together.

Consumers can order their pizzas by calling the single Happiness Hotline number 68886888 OR order online at Pizza Online</p>

</div></div>

<?php include('footer.php'); 
?>

</div>

</div>

</body>
</html>
