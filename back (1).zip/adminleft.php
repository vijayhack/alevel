<div class="login">
<h1 class="h1class">Admin Dashboard</h1>
<div class="content">

<ul>
<li style="color:#fff"><?php echo $_SESSION['admin_name']; ?> || <a href="adm-logout.php" style="color:#000"> <b>Logout</b></a></li>

</ul>
</div>
</div>


<div class="login">
<h1 class="h1class">Forms</h1>
<div class="content">
<ul>
<li><a href="add-category.php">Add Category</a></li>
<li><a href="add-sub.php">Add Subcategory</a></li>
<li><a href="Update_Order.php">Update Order</a></li>
</ul>
</div>
</div>

<div class="login">
<h1 class="h1class">Reports</h1>
<div class="content">
<ul>
<li><a href="cat_Details.php">Category Details</a></li>
<li><a href="sub_Details.php">Subcategory Details</a></li>
<li><a href="view_order_history.php">Check Order</a></li>
<li><a href="cust_display.php">Customer Details</a></li>
<li><a href="feed_welcome.php">Feedback Details</a></li>

</ul>
</div>
</div>