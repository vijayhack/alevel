<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="main" >
<?php include('header.php');
?>
<div class="body">

<div class="adminleft">
<?php include('left.php'); ?>
</div>

<br />
<div class="adminright">
<br />
<h1 style=" margin-left:10px; margin-right:10px;color:#942423">ContactUs</h1>

<p style="text-align: justify; margin-left:10px; margin-right:10px">
<b>Call </b>@ 011-65495934<br />
91-9313565406, 91-9015596280<br />

<b>Email</b> @ orderPizaa.com<br />
orderPizza@yahoo.com
</p>

</div></div>

<?php include('footer.php'); 
?>

</div>

</div>

</body>
</html>
